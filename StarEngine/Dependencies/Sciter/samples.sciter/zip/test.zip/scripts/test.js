
document.body.append(<h1>Passed!</h1>);